// Cloud Functions untuk TPQ Wardatul Wathon.
//
// Fungsi-fungsi di sini SENGAJA dipisah dari aplikasi client (index.html/js/*)
// karena butuh Firebase Admin SDK — hak akses penuh untuk membuat/mengubah
// akun Firebase Auth orang lain, sesuatu yang TIDAK BOLEH dilakukan dari
// browser admin secara langsung (client SDK `createUserWithEmailAndPassword`
// akan menggantikan sesi login admin yang sedang aktif dengan akun baru itu).
//
// Deploy dengan: firebase deploy --only functions
// (jalankan `npm install` di folder functions/ ini terlebih dahulu)

const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { setGlobalOptions } = require('firebase-functions/v2');
const admin = require('firebase-admin');

admin.initializeApp();
setGlobalOptions({ region: 'asia-southeast2', maxInstances: 10 }); // Jakarta

const AUTH_EMAIL_DOMAIN = 'tpq-wardatulwathon.app';
const emailFromUsername = (username) => `${username.trim().toLowerCase()}@${AUTH_EMAIL_DOMAIN}`;

/** Melempar HttpsError jika pemanggil bukan admin yang sah. */
async function assertIsAdmin(request) {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'Anda harus login terlebih dahulu.');
  }
  const profileSnap = await admin.firestore().collection('users').doc(request.auth.uid).get();
  if (!profileSnap.exists || profileSnap.data().role !== 'admin') {
    throw new HttpsError('permission-denied', 'Hanya admin yang boleh melakukan tindakan ini.');
  }
}

/**
 * provisionAccount — dipanggil admin saat menambahkan santri/ustadzah baru.
 *
 * Input: { role: 'wali'|'ustadzah'|'admin', username, password, displayName, refId }
 *   - refId untuk role 'wali' = id dokumen santri (users/{uid}.refId dipakai
 *     portal wali untuk tahu data santri mana yang ditampilkan).
 *   - refId untuk role 'ustadzah' = id dokumen ustadzah itu sendiri.
 * Output: { uid }
 */
exports.provisionAccount = onCall(async (request) => {
  await assertIsAdmin(request);

  const { role, username, password, displayName, refId } = request.data || {};

  if (!role || !['wali', 'ustadzah', 'admin'].includes(role)) {
    throw new HttpsError('invalid-argument', 'Role tidak valid.');
  }
  if (!username || username.trim().length < 3) {
    throw new HttpsError('invalid-argument', 'Username minimal 3 karakter.');
  }
  if (!password || password.length < 6) {
    throw new HttpsError('invalid-argument', 'Kata sandi minimal 6 karakter.');
  }
  if ((role === 'wali' || role === 'ustadzah') && !refId) {
    throw new HttpsError('invalid-argument', 'refId wajib diisi untuk role wali/ustadzah.');
  }

  const email = emailFromUsername(username);
  const db = admin.firestore();

  // Cegah username duplikat.
  const existing = await db.collection('users').where('username', '==', username.trim().toLowerCase()).limit(1).get();
  if (!existing.empty) {
    throw new HttpsError('already-exists', `Username "${username}" sudah dipakai. Pilih username lain.`);
  }

  let userRecord;
  try {
    userRecord = await admin.auth().createUser({ email, password, displayName: displayName || username });
  } catch (err) {
    if (err.code === 'auth/email-already-exists') {
      throw new HttpsError('already-exists', `Username "${username}" sudah dipakai. Pilih username lain.`);
    }
    throw new HttpsError('internal', 'Gagal membuat akun: ' + err.message);
  }

  const batch = db.batch();
  batch.set(db.collection('users').doc(userRecord.uid), {
    username: username.trim().toLowerCase(),
    role,
    displayName: displayName || username,
    refId: refId || null,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  if (role === 'wali') {
    batch.update(db.collection('santri').doc(refId), { waliUid: userRecord.uid });
  } else if (role === 'ustadzah') {
    batch.update(db.collection('ustadzah').doc(refId), { uid: userRecord.uid });
  }

  await batch.commit();

  return { uid: userRecord.uid, email };
});

/**
 * resetAccountPassword — admin mengatur ulang password akun (mis. wali/ustadzah lupa sandi).
 * Input: { uid, newPassword }
 */
exports.resetAccountPassword = onCall(async (request) => {
  await assertIsAdmin(request);
  const { uid, newPassword } = request.data || {};
  if (!uid || !newPassword || newPassword.length < 6) {
    throw new HttpsError('invalid-argument', 'uid dan kata sandi baru (min. 6 karakter) wajib diisi.');
  }
  await admin.auth().updateUser(uid, { password: newPassword });
  return { success: true };
});

/**
 * deactivateAccount — menonaktifkan (bukan menghapus) akun Firebase Auth saat
 * data santri/ustadzah terkait dihapus admin, supaya riwayat data historis
 * tetap konsisten tapi akun tidak bisa dipakai login lagi.
 * Input: { uid }
 */
exports.deactivateAccount = onCall(async (request) => {
  await assertIsAdmin(request);
  const { uid } = request.data || {};
  if (!uid) throw new HttpsError('invalid-argument', 'uid wajib diisi.');
  await admin.auth().updateUser(uid, { disabled: true });
  return { success: true };
});
