// State global aplikasi — sengaja sederhana (bukan Redux/dsb.) supaya mudah
// dibaca siapa pun yang melanjutkan proyek ini.
export const state = {
  session: null, // { uid, username, role, displayName, refId }
  ui: {
    adminTab: 'dashboard',
    financeTab: 'spp',
    recording: false,
    recordSeconds: 0,
    recordTimer: null,
    mediaRecorder: null,
    recordedChunks: [],
    recordedBlob: null,
    tempJilidFiles: { bacaan: null, hafalan: null }, // File object sementara sebelum diunggah
  },
};
