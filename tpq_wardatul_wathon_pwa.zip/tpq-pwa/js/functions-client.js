import { httpsCallable } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-functions.js';
import { functions } from './firebase-config.js';

/**
 * Membuat akun login baru (Firebase Auth + dokumen users/{uid}) untuk
 * wali atau ustadzah. Hanya bisa dipanggil oleh admin yang sedang login
 * (diverifikasi di sisi server oleh functions/index.js).
 *
 * @param {{role:'wali'|'ustadzah'|'admin', username:string, password:string, displayName:string, refId?:string}} data
 * @returns {Promise<{uid:string, email:string}>}
 */
export async function provisionAccount(data) {
  const fn = httpsCallable(functions, 'provisionAccount');
  const result = await fn(data);
  return result.data;
}

export async function resetAccountPassword(uid, newPassword) {
  const fn = httpsCallable(functions, 'resetAccountPassword');
  const result = await fn({ uid, newPassword });
  return result.data;
}

export async function deactivateAccount(uid) {
  const fn = httpsCallable(functions, 'deactivateAccount');
  const result = await fn({ uid });
  return result.data;
}

/** Menerjemahkan kode error HttpsError Cloud Functions ke pesan berbahasa Indonesia. */
export function mapFunctionsError(err) {
  const code = err?.code || '';
  if (code.includes('already-exists')) return err.message || 'Username sudah dipakai.';
  if (code.includes('invalid-argument')) return err.message || 'Data yang diisi belum lengkap/valid.';
  if (code.includes('permission-denied')) return 'Anda tidak memiliki izin untuk tindakan ini.';
  if (code.includes('unauthenticated')) return 'Sesi login Anda berakhir. Silakan masuk kembali.';
  return err?.message || 'Terjadi kesalahan. Silakan coba lagi.';
}
