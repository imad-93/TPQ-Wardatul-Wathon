// Konfigurasi Firebase — GANTI seluruh nilai di bawah dengan kredensial
// proyek Firebase Anda sendiri (Firebase Console → Project settings →
// General → "Your apps" → Web app → SDK setup and configuration).
//
// Nilai-nilai ini AMAN untuk ditaruh di kode sisi klien (bukan rahasia
// seperti API key server) — keamanan sesungguhnya diatur lewat
// firestore.rules & storage.rules, BUKAN dengan menyembunyikan config ini.

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import {
  getAuth,
  connectAuthEmulator,
} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js';
import {
  getFirestore,
  enableIndexedDbPersistence,
  connectFirestoreEmulator,
} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import {
  getStorage,
  connectStorageEmulator,
} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js';
import {
  getFunctions,
  connectFunctionsEmulator,
} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-functions.js';

const firebaseConfig = {
  apiKey: 'GANTI_DENGAN_API_KEY_ANDA',
  authDomain: 'GANTI.firebaseapp.com',
  projectId: 'GANTI_PROJECT_ID',
  storageBucket: 'GANTI.appspot.com',
  messagingSenderId: 'GANTI_SENDER_ID',
  appId: 'GANTI_APP_ID',
};

export const firebaseApp = initializeApp(firebaseConfig);
export const auth = getAuth(firebaseApp);
export const db = getFirestore(firebaseApp);
export const storage = getStorage(firebaseApp);
// Region harus sama persis dengan `setGlobalOptions` di functions/index.js.
export const functions = getFunctions(firebaseApp, 'asia-southeast2');

// Domain sintetis untuk memetakan username -> email Firebase Auth.
// Sama seperti pada kerangka Flutter: username "wali.ahmad" akan login
// dengan email "wali.ahmad@tpq-wardatulwathon.app".
export const AUTH_EMAIL_DOMAIN = 'tpq-wardatulwathon.app';
export const emailFromUsername = (username) =>
  `${username.trim().toLowerCase()}@${AUTH_EMAIL_DOMAIN}`;

// Offline persistence — inilah yang memberi kemampuan offline "gratis":
// Firestore otomatis menyimpan cache lokal (IndexedDB) dan mengantre
// perubahan data saat offline, lalu menyinkronkannya saat online kembali.
// Tidak berlaku untuk unggah file (Storage) — itu tetap butuh koneksi.
enableIndexedDbPersistence(db).catch((err) => {
  if (err.code === 'failed-precondition') {
    console.warn('Offline persistence hanya bisa aktif di satu tab. Tab lain akan tetap online-only.');
  } else if (err.code === 'unimplemented') {
    console.warn('Browser ini tidak mendukung offline persistence Firestore.');
  }
});

// --- Mode emulator lokal (opsional, untuk pengembangan) ---
// Uncomment blok ini saat menjalankan `firebase emulators:start` di lokal.
// const useEmulator = location.hostname === 'localhost';
// if (useEmulator) {
//   connectAuthEmulator(auth, 'http://localhost:9099');
//   connectFirestoreEmulator(db, 'localhost', 8080);
//   connectStorageEmulator(storage, 'localhost', 9199);
//   connectFunctionsEmulator(functions, 'localhost', 5001);
// }
