import {
  collection, doc, addDoc, setDoc, updateDoc, deleteDoc,
  onSnapshot, query, where, orderBy, limit,
  getDoc, getDocs, writeBatch, Timestamp, serverTimestamp,
} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import { db } from './firebase-config.js';

// ---------- helpers ----------
const col = (name) => collection(db, name);
const toDate = (ts) => (ts && ts.toDate ? ts.toDate() : ts ? new Date(ts) : null);

function mapDoc(d) {
  return { id: d.id, ...d.data() };
}

// ---------- Jilid / kelas ----------
export function watchJilid(cb) {
  return onSnapshot(query(col('jilid'), orderBy('nama')), (snap) => cb(snap.docs.map(mapDoc)));
}
export async function getJilid(jilidId) {
  const d = await getDoc(doc(db, 'jilid', jilidId));
  return d.exists() ? { id: d.id, ...d.data() } : null;
}
export async function upsertJilid(jilidId, data) {
  const ref = jilidId ? doc(db, 'jilid', jilidId) : doc(col('jilid'));
  await setDoc(ref, data, { merge: true });
  return ref.id;
}

// ---------- Ustadzah ----------
export function watchUstadzah(cb) {
  return onSnapshot(query(col('ustadzah'), orderBy('nama')), (snap) => cb(snap.docs.map(mapDoc)));
}
export async function getUstadzahByJilid(jilidId) {
  const q = query(col('ustadzah'), where('jilidId', '==', jilidId), limit(1));
  const snap = await getDocs(q);
  return snap.empty ? null : mapDoc(snap.docs[0]);
}
export async function addUstadzah(data) {
  const ref = await addDoc(col('ustadzah'), data);
  return ref.id;
}
export async function updateUstadzah(id, data) {
  await updateDoc(doc(db, 'ustadzah', id), data);
}
export async function deleteUstadzah(id) {
  await deleteDoc(doc(db, 'ustadzah', id));
}

// ---------- Santri ----------
export function watchAllSantri(cb) {
  return onSnapshot(query(col('santri'), orderBy('nama')), (snap) => cb(snap.docs.map(mapDoc)));
}
export function watchSantriByJilid(jilidId, cb) {
  const q = query(col('santri'), where('jilidId', '==', jilidId), orderBy('nama'));
  return onSnapshot(q, (snap) => cb(snap.docs.map(mapDoc)));
}
export async function getSantriById(santriId) {
  const d = await getDoc(doc(db, 'santri', santriId));
  return d.exists() ? { id: d.id, ...d.data() } : null;
}
export async function addSantri(data) {
  const ref = await addDoc(col('santri'), data);
  return ref.id;
}
export async function updateSantri(id, data) {
  await updateDoc(doc(db, 'santri', id), data);
}
export async function deleteSantri(id) {
  await deleteDoc(doc(db, 'santri', id));
}

// ---------- Riwayat ngaji (bacaan / hafalan) ----------
function riwayatCollection(santriId, hafalan) {
  return collection(db, 'santri', santriId, hafalan ? 'riwayat_hafalan' : 'riwayat_bacaan');
}
export function watchRiwayat(santriId, hafalan, cb) {
  const q = query(riwayatCollection(santriId, hafalan), orderBy('tanggal', 'desc'));
  return onSnapshot(q, (snap) => cb(snap.docs.map(mapDoc)));
}
export async function tambahRiwayat(santriId, hafalan, entry) {
  await addDoc(riwayatCollection(santriId, hafalan), {
    ...entry,
    tanggal: entry.tanggal instanceof Date ? Timestamp.fromDate(entry.tanggal) : serverTimestamp(),
  });
}

// ---------- Keuangan ----------
function keuanganCollection(santriId) {
  return collection(db, 'santri', santriId, 'keuangan');
}
export function watchKeuangan(santriId, cb, jenis) {
  const q = jenis
    ? query(keuanganCollection(santriId), where('jenis', '==', jenis))
    : query(keuanganCollection(santriId));
  return onSnapshot(q, (snap) => cb(snap.docs.map(mapDoc)));
}
export async function tandaiLunas(santriId, tagihanId, metode) {
  await updateDoc(doc(db, 'santri', santriId, 'keuangan', tagihanId), {
    status: 'lunas',
    metode,
    tanggalBayar: serverTimestamp(),
  });
}
export async function tambahTagihan(santriId, tagihan) {
  await addDoc(keuanganCollection(santriId), tagihan);
}
export async function broadcastIuranKeSemuaSantri(santriIds, label, nominal) {
  const batch = writeBatch(db);
  santriIds.forEach((id) => {
    const ref = doc(keuanganCollection(id));
    batch.set(ref, { jenis: 'iuran', label, nominal, status: 'belum', metode: '-', tanggalBayar: null });
  });
  await batch.commit();
}

// ---------- Pengumuman ----------
export function watchPengumuman(cb) {
  const q = query(col('pengumuman'), orderBy('tanggal', 'desc'));
  return onSnapshot(q, (snap) => cb(snap.docs.map(mapDoc)));
}
export async function tambahPengumuman(judul, isi) {
  await addDoc(col('pengumuman'), { judul, isi, tanggal: serverTimestamp() });
}
export async function hapusPengumuman(id) {
  await deleteDoc(doc(db, 'pengumuman', id));
}

// ---------- Settings ----------
export function watchSettings(cb) {
  return onSnapshot(doc(db, 'settings', 'umum'), (snap) => cb(snap.exists() ? snap.data() : {}));
}
export async function updateSettings(partial) {
  await setDoc(doc(db, 'settings', 'umum'), partial, { merge: true });
}
export function watchIuranItems(cb) {
  const q = query(collection(db, 'settings', 'umum', 'iuran_items'), orderBy('deadline'));
  return onSnapshot(q, (snap) => cb(snap.docs.map(mapDoc)));
}
export async function tambahIuranSetting(nama, nominal, deadline) {
  await addDoc(collection(db, 'settings', 'umum', 'iuran_items'), {
    nama,
    nominal,
    deadline: Timestamp.fromDate(deadline),
  });
}
export async function hapusIuranSetting(id) {
  await deleteDoc(doc(db, 'settings', 'umum', 'iuran_items', id));
}

export { toDate };
