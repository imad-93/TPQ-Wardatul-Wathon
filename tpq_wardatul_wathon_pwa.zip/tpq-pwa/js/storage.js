import { ref, uploadBytes, getDownloadURL } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js';
import { storage } from './firebase-config.js';

async function uploadAndGetUrl(path, file, contentType) {
  const storageRef = ref(storage, path);
  await uploadBytes(storageRef, file, contentType ? { contentType } : undefined);
  return getDownloadURL(storageRef);
}

export async function uploadBookPdf(jilidId, hafalan, file) {
  const folder = hafalan ? 'hafalan' : 'bacaan';
  return uploadAndGetUrl(`books/${jilidId}/${folder}/${file.name}`, file, 'application/pdf');
}

export async function uploadLogo(file) {
  return uploadAndGetUrl('branding/logo.png', file, file.type);
}

export async function uploadQris(file) {
  return uploadAndGetUrl('branding/qris.png', file, file.type);
}

export async function uploadVoiceNote(santriId, blob, fileName) {
  return uploadAndGetUrl(`voice_notes/${santriId}/${fileName}`, blob, 'audio/webm');
}
