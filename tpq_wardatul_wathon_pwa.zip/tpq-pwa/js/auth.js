// PENTING — cara kerja "akun = username, login cukup password" di web:
//
// Karena ini PWA (satu alamat web untuk semua orang, bukan APK per-orang),
// konsepnya diwujudkan lewat AKTIVASI PERTAMA KALI per perangkat/browser:
//
// 1. Admin menambahkan santri/ustadzah baru → sistem membuat akun Firebase
//    Auth dengan email sintetis `{username}@tpq-wardatulwathon.app` (lihat
//    catatan provisioning di db.js — idealnya lewat Cloud Function).
// 2. Wali/ustadzah menerima username + password awal dari admin.
// 3. Pertama kali membuka PWA di HP-nya, mereka mengisi USERNAME + PASSWORD
//    satu kali. Username lalu disimpan di localStorage browser/PWA itu.
// 4. Setiap kali PWA dibuka lagi (termasuk setelah "Add to Home Screen"),
//    layar login hanya menampilkan kolom PASSWORD.
//
// Catatan: localStorage bersifat per-browser/per-perangkat. Jika wali
// memakai PWA di HP dan browser desktop, aktivasi tetap perlu dilakukan
// sekali di masing-masing.

import { signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js';
import { doc, getDoc } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import { auth, db, emailFromUsername } from './firebase-config.js';
import { state } from './state.js';

const LS_USERNAME = 'tpq_activated_username';

export function getActivatedUsername() {
  return localStorage.getItem(LS_USERNAME);
}

function rememberUsername(username) {
  localStorage.setItem(LS_USERNAME, username);
}

export function forgetActivatedUsername() {
  localStorage.removeItem(LS_USERNAME);
}

export async function login(username, password) {
  const email = emailFromUsername(username);
  const cred = await signInWithEmailAndPassword(auth, email, password);
  const uid = cred.user.uid;

  const profileSnap = await getDoc(doc(db, 'users', uid));
  if (!profileSnap.exists()) {
    await signOut(auth);
    throw new Error('Profil pengguna tidak ditemukan di Firestore. Hubungi admin TPQ.');
  }

  rememberUsername(username);
  const profile = profileSnap.data();
  state.session = { uid, username, ...profile };
  return state.session;
}

export async function logout({ forgetDevice = false } = {}) {
  await signOut(auth);
  state.session = null;
  if (forgetDevice) forgetActivatedUsername();
}

/** Memantau status login Firebase Auth dan memuat profil Firestore terkait. */
export function watchAuthState(callback) {
  onAuthStateChanged(auth, async (user) => {
    if (!user) {
      state.session = null;
      callback(null);
      return;
    }
    const profileSnap = await getDoc(doc(db, 'users', user.uid));
    if (!profileSnap.exists()) {
      callback(null);
      return;
    }
    state.session = { uid: user.uid, ...profileSnap.data() };
    callback(state.session);
  });
}
