export function showToast(msg) {
  const t = document.getElementById('toast');
  document.getElementById('toast-text').textContent = msg;
  t.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
}

export function openModal(html, wide = false) {
  document.getElementById('modal-box').className = 'modal-box' + (wide ? ' wide' : '');
  document.getElementById('modal-box').innerHTML = html;
  document.getElementById('modal-backdrop').classList.add('open');
}

export function closeModal() {
  document.getElementById('modal-backdrop').classList.remove('open');
}

document.addEventListener('DOMContentLoaded', () => {
  const backdrop = document.getElementById('modal-backdrop');
  backdrop?.addEventListener('click', (e) => {
    if (e.target === backdrop) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && backdrop?.classList.contains('open')) closeModal();
  });
});

export function badge(label, tone = 'green', icon = '') {
  return `<span class="badge badge-${tone}">${icon}${label}</span>`;
}

export function emptyNote(msg) {
  return `<div class="empty-note">${msg}</div>`;
}

export function loadingNote(msg = 'Memuat...') {
  return `<div class="loading-note">${msg}</div>`;
}

/** Terapkan logo lembaga (jika ada) ke badge login & topbar. */
export function applyBranding(logoUrl) {
  const badgeEl = document.getElementById('login-badge-el');
  const markEl = document.getElementById('topbar-mark-el');
  const inner = logoUrl ? `<img src="${logoUrl}" alt="Logo TPQ Wardatul Wathon">` : 'TW';
  if (badgeEl) badgeEl.innerHTML = inner;
  if (markEl) markEl.innerHTML = inner;
}

/** Banner status koneksi online/offline. */
export function initOfflineBanner() {
  const banner = document.getElementById('offline-banner');
  const update = () => {
    if (navigator.onLine) {
      banner.classList.remove('show');
    } else {
      banner.textContent = '📴 Anda sedang offline — perubahan akan tersinkron otomatis saat koneksi kembali.';
      banner.classList.add('show');
    }
  };
  window.addEventListener('online', update);
  window.addEventListener('offline', update);
  update();
}

/** Tombol "Pasang aplikasi" memakai event beforeinstallprompt (Android/Chrome). */
export function initInstallPrompt() {
  let deferredPrompt = null;
  const banner = document.getElementById('install-banner');
  const btnInstall = document.getElementById('btn-install');
  const btnDismiss = document.getElementById('btn-dismiss-install');

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    if (!localStorage.getItem('tpq_install_dismissed')) {
      banner.classList.add('show');
    }
  });

  btnInstall?.addEventListener('click', async () => {
    banner.classList.remove('show');
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
  });

  btnDismiss?.addEventListener('click', () => {
    banner.classList.remove('show');
    localStorage.setItem('tpq_install_dismissed', '1');
  });

  window.addEventListener('appinstalled', () => {
    banner.classList.remove('show');
  });
}
