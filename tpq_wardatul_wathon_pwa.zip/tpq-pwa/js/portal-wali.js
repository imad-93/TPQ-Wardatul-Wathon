import { getSantriById, getJilid, getUstadzahByJilid, watchPengumuman, watchRiwayat, watchKeuangan, tandaiLunas, watchSettings } from './db.js';
import { rupiah, tanggalIndo, initials, escapeHtml } from './formatters.js';
import { openModal, closeModal, showToast, emptyNote, loadingNote } from './ui-shared.js';

export async function renderWaliDashboard(session) {
  const content = document.getElementById('content');
  const santriId = session.refId;

  if (!santriId) {
    content.innerHTML = `<div class="panel">${emptyNote('Data santri tidak ditemukan untuk akun ini. Hubungi admin TPQ.')}</div>`;
    return;
  }

  content.innerHTML = loadingNote('Memuat data santri...');
  const santri = await getSantriById(santriId);
  if (!santri) {
    content.innerHTML = `<div class="panel">${emptyNote('Data santri tidak ditemukan.')}</div>`;
    return;
  }
  const jilid = await getJilid(santri.jilidId);
  const ustadzah = await getUstadzahByJilid(santri.jilidId);

  content.innerHTML = `
    <div class="hero">
      <div class="hero-eyebrow">Assalamu'alaikum, ${escapeHtml(session.displayName || session.username)}</div>
      <h2>${escapeHtml(santri.nama)}</h2>
      <p>Sedang menempuh ${escapeHtml(jilid?.nama || '-')}${ustadzah ? `, didampingi oleh ${escapeHtml(ustadzah.nama)}` : ''}. Pantau perkembangan mengaji dan riwayat pembayaran di bawah ini.</p>
    </div>

    <div class="grid grid-2" style="margin-bottom:16px;">
      <div class="panel">
        <div class="panel-head"><h3>Ustadzah pendamping</h3></div>
        <div id="ustadzah-card">${loadingNote()}</div>
      </div>
      <div class="panel">
        <div class="panel-head"><h3>Pengumuman</h3></div>
        <div id="pengumuman-card">${loadingNote()}</div>
      </div>
    </div>

    <div class="panel" style="margin-bottom:16px;">
      <div class="panel-head"><div><h3>Riwayat ngaji</h3><div class="sub">Bacaan terakhir ${escapeHtml(jilid?.nama || '')}</div></div></div>
      <div class="table-scroll" id="riwayat-ngaji-table">${loadingNote()}</div>
    </div>

    <div class="panel">
      <div class="panel-head"><div><h3>Riwayat keuangan</h3><div class="sub">SPP &amp; tabungan</div></div></div>
      <div class="table-scroll" id="riwayat-keuangan-table">${loadingNote()}</div>
    </div>
  `;

  // Ustadzah pendamping
  const ustadzahCard = document.getElementById('ustadzah-card');
  if (ustadzah) {
    ustadzahCard.innerHTML = `
      <div class="person-row">
        <div class="avatar gold">${initials(ustadzah.nama)}</div>
        <div>
          <div style="font-weight:600;font-size:14.5px;">${escapeHtml(ustadzah.nama)}</div>
          <div style="font-size:12.5px;color:var(--ink-faint);">${escapeHtml(ustadzah.hp || '')}</div>
        </div>
      </div>`;
  } else {
    ustadzahCard.innerHTML = emptyNote('Ustadzah belum ditentukan.');
  }

  // Pengumuman (realtime)
  watchPengumuman((list) => {
    const el = document.getElementById('pengumuman-card');
    if (!el) return;
    const top3 = list.slice(0, 3);
    el.innerHTML = top3.length === 0
      ? emptyNote('Belum ada pengumuman.')
      : top3.map((p) => `
          <div class="announce-item">
            <div class="a-title">${escapeHtml(p.judul)}</div>
            <div class="a-date">${tanggalIndo(p.tanggal)}</div>
            <div class="a-body">${escapeHtml(p.isi)}</div>
          </div>`).join('');
  });

  // Riwayat ngaji bacaan (realtime)
  watchRiwayat(santriId, false, (list) => {
    const el = document.getElementById('riwayat-ngaji-table');
    if (!el) return;
    if (list.length === 0) {
      el.innerHTML = emptyNote('Belum ada riwayat ngaji.');
      return;
    }
    el.innerHTML = `
      <table>
        <thead><tr><th>No.</th><th>Halaman terakhir</th><th>Status</th><th>Pesan ustadzah</th><th>Lihat halaman</th></tr></thead>
        <tbody>
          ${list.map((r, i) => `
            <tr>
              <td>${i + 1}</td>
              <td>Halaman ${r.halaman}</td>
              <td>${r.status === 'naik'
                ? '<span class="badge badge-green"><i class="fa-solid fa-arrow-up"></i> Naik</span>'
                : '<span class="badge badge-brick"><i class="fa-solid fa-rotate-left"></i> Mengulang</span>'}</td>
              <td>${r.pesanTipe === 'suara'
                ? `<div class="voice-msg"><button class="vm-play" onclick="window.open('${r.audioUrl || '#'}','_blank')"><i class="fa-solid fa-play"></i></button>${escapeHtml(r.pesan)}</div>`
                : escapeHtml(r.pesan || '-')}</td>
              <td><button class="btn btn-ghost btn-sm" data-page="${r.halaman}" data-buku="${escapeHtml(jilid?.bukuBacaanNama || '-')}" data-url="${jilid?.bukuBacaanUrl || ''}" class="btn-lihat-halaman"><i class="fa-solid fa-eye"></i> Lihat</button></td>
            </tr>`).join('')}
        </tbody>
      </table>`;

    el.querySelectorAll('.btn-lihat-halaman').forEach((btn) => {
      btn.addEventListener('click', () => showPageViewer(btn.dataset.buku, btn.dataset.page, btn.dataset.url));
    });
  });

  // Riwayat keuangan (realtime)
  watchKeuangan(santriId, (list) => {
    const el = document.getElementById('riwayat-keuangan-table');
    if (!el) return;
    if (list.length === 0) {
      el.innerHTML = emptyNote('Belum ada tagihan.');
      return;
    }
    el.innerHTML = `
      <table>
        <thead><tr><th>No.</th><th>Tagihan bulanan</th><th>Nilai tagihan</th><th>Terbayar</th><th>Aksi</th></tr></thead>
        <tbody>
          ${list.map((k, i) => `
            <tr>
              <td>${i + 1}</td>
              <td>${escapeHtml(k.label)}</td>
              <td>${rupiah(k.nominal)}</td>
              <td>${k.status === 'lunas'
                ? `<span class="badge badge-green"><i class="fa-solid fa-circle-check"></i> Lunas · ${tanggalIndo(k.tanggalBayar)}</span>`
                : `<span class="badge badge-brick"><i class="fa-solid fa-circle-exclamation"></i> Belum bayar</span>`}</td>
              <td>${k.status === 'lunas'
                ? `<span style="font-size:12px;color:var(--ink-faint);">via ${escapeHtml(k.metode || '-')}</span>`
                : `<button class="btn btn-gold btn-sm btn-bayar-qris" data-id="${k.id}"><i class="fa-solid fa-qrcode"></i> Bayar QRIS</button>`}</td>
            </tr>`).join('')}
        </tbody>
      </table>`;

    el.querySelectorAll('.btn-bayar-qris').forEach((btn) => {
      const tagihan = list.find((k) => k.id === btn.dataset.id);
      btn.addEventListener('click', () => showQrisModal(santriId, tagihan));
    });
  });
}

let pdfWorkerConfigured = false;

/** Menunggu skrip pdf.js (dimuat via <script defer> di index.html) siap dipakai. */
function ensurePdfJs(timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    (function poll() {
      if (window.pdfjsLib) {
        if (!pdfWorkerConfigured) {
          window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
          pdfWorkerConfigured = true;
        }
        resolve(window.pdfjsLib);
        return;
      }
      if (Date.now() - start > timeoutMs) { reject(new Error('pdf.js gagal dimuat')); return; }
      setTimeout(poll, 150);
    })();
  });
}

function showPageViewer(buku, halaman, pdfUrl) {
  const pageNum = parseInt(halaman, 10) || 1;

  openModal(`
    <div class="modal-head">
      <div><h3>Halaman terakhir dibaca</h3><div class="sub">${escapeHtml(buku)}</div></div>
      <button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="text-align:center;">
      ${pdfUrl ? `
        <div id="pdf-canvas-wrap" style="background:var(--paper-deep);border-radius:12px;padding:12px;min-height:200px;display:flex;align-items:center;justify-content:center;">
          <div id="pdf-status" style="font-size:12.5px;color:var(--ink-faint);">Memuat halaman ${pageNum}...</div>
          <canvas id="pdf-canvas" style="max-width:100%;border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,0.15);display:none;"></canvas>
        </div>
        <a href="${pdfUrl}#page=${pageNum}" target="_blank" rel="noopener" style="display:inline-block;margin-top:12px;font-size:12.5px;color:var(--pine);">
          <i class="fa-solid fa-up-right-from-square"></i> Buka PDF lengkap di tab baru
        </a>
      ` : `
        <div class="page-viewer">
          <div class="pv-book">${escapeHtml(buku)}</div>
          <div class="pv-page">Hal. ${pageNum}</div>
          <div class="pv-note">Admin belum mengunggah file PDF untuk buku ini.</div>
        </div>
      `}
    </div>
  `);

  if (pdfUrl) renderPdfPage(pdfUrl, pageNum);
}

async function renderPdfPage(pdfUrl, pageNum) {
  const statusEl = document.getElementById('pdf-status');
  const canvas = document.getElementById('pdf-canvas');
  try {
    const pdfjsLib = await ensurePdfJs();
    const pdf = await pdfjsLib.getDocument(pdfUrl).promise;
    const safePage = Math.min(Math.max(pageNum, 1), pdf.numPages);
    const page = await pdf.getPage(safePage);

    const containerWidth = document.getElementById('pdf-canvas-wrap')?.clientWidth || 480;
    const baseViewport = page.getViewport({ scale: 1 });
    const scale = Math.min((containerWidth - 24) / baseViewport.width, 1.6);
    const viewport = page.getViewport({ scale });

    if (!canvas) return; // modal sudah ditutup sebelum PDF selesai dimuat
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;

    if (statusEl) statusEl.style.display = 'none';
    canvas.style.display = 'block';
  } catch (err) {
    if (statusEl) {
      statusEl.textContent = 'Gagal memuat pratinjau PDF. Gunakan tautan "Buka PDF lengkap" di bawah.';
      statusEl.style.color = 'var(--brick)';
    }
  }
}

async function showQrisModal(santriId, tagihan) {
  const settings = await new Promise((resolve) => {
    const unsub = watchSettings((s) => { unsub(); resolve(s); });
  });

  openModal(`
    <div class="modal-head">
      <div><h3>Pembayaran QRIS</h3><div class="sub">${escapeHtml(tagihan.label)}</div></div>
      <button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="text-align:center;">
      <div class="qr-box">
        ${settings.qrisUrl
          ? `<img src="${settings.qrisUrl}" alt="Kode QRIS TPQ Wardatul Wathon">`
          : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--ink-faint);"><i class="fa-solid fa-qrcode" style="font-size:64px;"></i></div>`}
      </div>
      <div style="font-size:13px;color:var(--ink-faint);">Nominal tagihan</div>
      <div style="font-family:'Fraunces',serif;font-size:26px;margin:2px 0 14px;">${rupiah(tagihan.nominal)}</div>
      <p style="font-size:12.5px;color:var(--ink-soft);line-height:1.6;">Pindai kode QRIS di atas menggunakan aplikasi m-banking atau e-wallet mana pun.</p>
      <p style="font-size:11px;color:var(--ink-faint);">Catatan kerangka: status pembayaran di sini masih disimulasikan. Produksi sesungguhnya perlu integrasi payment gateway resmi (mis. Midtrans/Xendit) dengan webhook yang menandai lunas otomatis.</p>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="document.getElementById('modal-backdrop').classList.remove('open')">Tutup</button>
      <button class="btn btn-primary" id="btn-simulasi-bayar">Simulasikan pembayaran berhasil</button>
    </div>
  `);

  document.getElementById('btn-simulasi-bayar').addEventListener('click', async () => {
    await tandaiLunas(santriId, tagihan.id, 'QRIS');
    closeModal();
    showToast('Pembayaran berhasil dicatat via QRIS');
  });
}
