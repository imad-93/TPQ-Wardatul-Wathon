import { login, logout, watchAuthState, getActivatedUsername, forgetActivatedUsername } from './auth.js';
import { watchSettings } from './db.js';
import { state } from './state.js';
import { applyBranding, initOfflineBanner, initInstallPrompt, showToast } from './ui-shared.js';
import { renderWaliDashboard } from './portal-wali.js';
import { renderUstadzahShell } from './portal-ustadzah.js';
import { renderAdminShell } from './portal-admin.js';

initOfflineBanner();
initInstallPrompt();

// Terapkan logo lembaga (kalau sudah diatur admin) begitu tersedia,
// termasuk saat masih di layar login.
watchSettings((settings) => applyBranding(settings.logoUrl));

renderLoginScreen();

watchAuthState((session) => {
  if (session) {
    showAppShell(session);
  } else {
    document.getElementById('app-shell').style.display = 'none';
    document.getElementById('login-screen').style.display = 'flex';
    renderLoginScreen();
  }
});

document.getElementById('btn-logout').addEventListener('click', async () => {
  await logout({ forgetDevice: false });
});

function renderLoginScreen() {
  const activatedUsername = getActivatedUsername();
  const body = document.getElementById('login-body');

  if (!activatedUsername) {
    body.innerHTML = `
      <div class="field">
        <label>Username (diberikan admin TPQ)</label>
        <input type="text" id="login-username" placeholder="contoh: wali.ahmad">
      </div>
      <div class="field">
        <label>Kata sandi</label>
        <input type="password" id="login-password" placeholder="Masukkan kata sandi">
      </div>
      <div class="login-error" id="login-error"></div>
      <button class="btn btn-primary" id="btn-submit-login">Aktivasi & Masuk</button>
      <div class="login-demo-note" style="margin-top:16px;padding:11px 13px;background:var(--gold-soft);border-radius:6px;font-size:12px;color:#5c4413;line-height:1.5;">
        Aktivasi ini hanya dilakukan sekali di perangkat ini. Setelah berhasil, kunjungan berikutnya cukup memasukkan kata sandi.
      </div>
    `;
  } else {
    body.innerHTML = `
      <div class="field">
        <label>Akun pada perangkat ini</label>
        <div class="field-static">@${activatedUsername}</div>
      </div>
      <div class="field">
        <label>Kata sandi</label>
        <input type="password" id="login-password" placeholder="Masukkan kata sandi">
      </div>
      <div class="login-error" id="login-error"></div>
      <button class="btn btn-primary" id="btn-submit-login">Masuk</button>
      <button class="login-link" id="btn-ganti-akun">Bukan Anda? Ganti akun</button>
    `;
  }

  document.getElementById('btn-submit-login').addEventListener('click', handleLoginSubmit);
  document.getElementById('login-password')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleLoginSubmit();
  });
  document.getElementById('btn-ganti-akun')?.addEventListener('click', () => {
    forgetActivatedUsername();
    renderLoginScreen();
  });
}

async function handleLoginSubmit() {
  const activatedUsername = getActivatedUsername();
  const username = activatedUsername || document.getElementById('login-username')?.value.trim();
  const password = document.getElementById('login-password').value;
  const errorEl = document.getElementById('login-error');
  const btn = document.getElementById('btn-submit-login');

  errorEl.style.display = 'none';
  if (!username) {
    errorEl.textContent = 'Username wajib diisi pada aktivasi pertama.';
    errorEl.style.display = 'block';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Memproses...';
  try {
    await login(username, password);
    // watchAuthState akan otomatis memanggil showAppShell()
  } catch (err) {
    const msg = mapAuthError(err);
    errorEl.textContent = msg;
    errorEl.style.display = 'block';
    btn.disabled = false;
    btn.textContent = activatedUsername ? 'Masuk' : 'Aktivasi & Masuk';
  }
}

function mapAuthError(err) {
  const code = err?.code || '';
  if (code.includes('user-not-found') || code.includes('wrong-password') || code.includes('invalid-credential')) {
    return 'Username atau kata sandi salah.';
  }
  if (code.includes('too-many-requests')) {
    return 'Terlalu banyak percobaan. Coba lagi beberapa saat lagi.';
  }
  if (code.includes('network-request-failed')) {
    return 'Tidak ada koneksi internet. Login pertama kali membutuhkan koneksi.';
  }
  return err?.message || 'Gagal masuk. Silakan coba lagi.';
}

function showAppShell(session) {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('app-shell').style.display = 'block';

  const roleLabel = session.role === 'wali' ? 'Portal Wali' : session.role === 'ustadzah' ? 'Portal Ustadzah' : 'Portal Admin';
  document.getElementById('topbar-role-label').textContent = roleLabel;
  document.getElementById('topbar-username').textContent = session.displayName || session.username;
  document.getElementById('topbar-usersub').textContent = '@' + session.username;

  if (session.role === 'wali') {
    document.getElementById('sidebar').innerHTML = `<div class="nav-item active"><i class="fa-solid fa-house"></i><span>Dashboard</span></div>`;
    renderWaliDashboard(session);
  } else if (session.role === 'ustadzah') {
    document.getElementById('sidebar').innerHTML = `<div class="nav-item active"><i class="fa-solid fa-house"></i><span>Dashboard</span></div>`;
    renderUstadzahShell(session);
  } else if (session.role === 'admin') {
    renderAdminShell(session);
  } else {
    showToast('Role akun tidak dikenali. Hubungi admin.');
  }
}
