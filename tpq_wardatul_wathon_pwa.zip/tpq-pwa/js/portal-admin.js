import {
  watchJilid, getJilid, upsertJilid, watchUstadzah, addUstadzah, updateUstadzah,
  watchAllSantri, watchSantriByJilid, addSantri, updateSantri, deleteSantri,
  watchPengumuman, tambahPengumuman, hapusPengumuman,
  watchSettings, updateSettings, watchIuranItems, tambahIuranSetting, hapusIuranSetting,
  broadcastIuranKeSemuaSantri,
} from './db.js';
import { uploadBookPdf, uploadLogo, uploadQris } from './storage.js';
import { provisionAccount, resetAccountPassword, deactivateAccount, mapFunctionsError } from './functions-client.js';
import { rupiah, tanggalIndo, escapeHtml } from './formatters.js';
import { openModal, closeModal, showToast, emptyNote, loadingNote, applyBranding } from './ui-shared.js';
import { state } from './state.js';

export function renderAdminShell(session) {
  state.ui.adminTab = 'dashboard';
  renderSidebar();
  renderAdminContent();
}

function renderSidebar() {
  const items = [
    { k: 'dashboard', icon: 'fa-house', label: 'Dashboard' },
    { k: 'santri', icon: 'fa-child-reaching', label: 'Data Santri' },
    { k: 'guru', icon: 'fa-chalkboard-user', label: 'Data Guru' },
    { k: 'jilid', icon: 'fa-layer-group', label: 'Jilid / Kelas' },
    { k: 'pengaturan', icon: 'fa-gear', label: 'Pengaturan' },
  ];
  const sb = document.getElementById('sidebar');
  sb.innerHTML = items.map((it) => `
    <div class="nav-item ${state.ui.adminTab === it.k ? 'active' : ''}" data-tab="${it.k}">
      <i class="fa-solid ${it.icon}"></i><span>${it.label}</span>
    </div>`).join('');
  sb.querySelectorAll('.nav-item').forEach((el) => {
    el.addEventListener('click', () => {
      state.ui.adminTab = el.dataset.tab;
      renderSidebar();
      renderAdminContent();
    });
  });
}

function renderAdminContent() {
  const tab = state.ui.adminTab;
  if (tab === 'dashboard') return renderDashboard();
  if (tab === 'santri') return renderSantriTab();
  if (tab === 'guru') return renderGuruTab();
  if (tab === 'jilid') return renderJilidTab();
  if (tab === 'pengaturan') return renderPengaturanTab();
}

// ============================================================
// Dashboard
// ============================================================
function renderDashboard() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="hero">
      <div class="hero-eyebrow">Ringkasan TPQ Wardatul Wathon</div>
      <h2>Tukum Kidul, Lumajang</h2>
      <p>Pantau data santri, guru, kelas, dan keuangan dari satu tempat.</p>
    </div>
    <div class="grid grid-3" style="margin-bottom:18px;">
      <div class="stat-card"><div class="stat-label">Total santri</div><div class="stat-value" id="stat-total-santri">-</div><div class="stat-note">aktif terdaftar</div></div>
      <div class="stat-card gold"><div class="stat-label">Total ustadzah</div><div class="stat-value" id="stat-total-guru">-</div><div class="stat-note">pengajar aktif</div></div>
      <div class="stat-card"><div class="stat-label">Jilid / kelas</div><div class="stat-value" id="stat-total-jilid">-</div><div class="stat-note">kelas berjalan</div></div>
    </div>
    <div class="grid grid-2">
      <div class="panel">
        <div class="panel-head"><h3>Distribusi santri per jilid</h3></div>
        <div id="distribusi-jilid">${loadingNote()}</div>
      </div>
      <div class="panel">
        <div class="panel-head"><h3>Pengumuman terbaru</h3></div>
        <div id="pengumuman-ringkas">${loadingNote()}</div>
      </div>
    </div>
  `;

  watchAllSantri((list) => { document.getElementById('stat-total-santri').textContent = list.length; });
  watchUstadzah((list) => { document.getElementById('stat-total-guru').textContent = list.length; });
  watchJilid((list) => {
    document.getElementById('stat-total-jilid').textContent = list.length;
    const el = document.getElementById('distribusi-jilid');
    if (list.length === 0) { el.innerHTML = emptyNote('Belum ada jilid/kelas.'); return; }
    el.innerHTML = list.map((j) => `<div id="dist-row-${j.id}" style="display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid var(--line);">
      <div style="font-weight:600;font-size:13.5px;">${escapeHtml(j.nama)}</div>
      <span class="badge badge-green" id="dist-count-${j.id}">…</span>
    </div>`).join('');
    list.forEach((j) => {
      watchSantriByJilid(j.id, (santriList) => {
        const badge = document.getElementById(`dist-count-${j.id}`);
        if (badge) badge.textContent = `${santriList.length} santri`;
      });
    });
  });
  watchPengumuman((list) => {
    const el = document.getElementById('pengumuman-ringkas');
    const top3 = list.slice(0, 3);
    el.innerHTML = top3.length === 0 ? emptyNote('Belum ada pengumuman.') : top3.map((p) => `
      <div class="announce-item"><div class="a-title">${escapeHtml(p.judul)}</div><div class="a-date">${tanggalIndo(p.tanggal)}</div></div>
    `).join('');
  });
}

// ============================================================
// Data santri
// ============================================================
function renderSantriTab() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="panel">
      <div class="panel-head">
        <div><h3>Data santri</h3><div class="sub" id="santri-count">Memuat...</div></div>
        <button class="btn btn-primary btn-sm" id="btn-tambah-santri"><i class="fa-solid fa-plus"></i> Tambah santri</button>
      </div>
      <div class="table-scroll" id="santri-list">${loadingNote()}</div>
    </div>
  `;
  document.getElementById('btn-tambah-santri').addEventListener('click', () => openSantriForm());

  watchJilid((jilidList) => {
    const jilidMap = Object.fromEntries(jilidList.map((j) => [j.id, j]));
    watchAllSantri((list) => {
      document.getElementById('santri-count').textContent = `${list.length} santri terdaftar`;
      const el = document.getElementById('santri-list');
      if (list.length === 0) { el.innerHTML = emptyNote('Belum ada santri terdaftar.'); return; }
      el.innerHTML = `
        <table>
          <thead><tr><th>No.</th><th>Nama santri</th><th>Jilid / kelas</th><th>Wali</th><th>No. HP wali</th><th>Aksi</th></tr></thead>
          <tbody>
            ${list.map((s, i) => `
              <tr>
                <td>${i + 1}</td>
                <td style="font-weight:600;">${escapeHtml(s.nama)}</td>
                <td>${escapeHtml(jilidMap[s.jilidId]?.nama || '—')}</td>
                <td>${escapeHtml(s.waliNama || '-')}</td>
                <td>${escapeHtml(s.waliHp || '-')}</td>
                <td>
                  <button class="action-icon btn-edit-santri" data-id="${s.id}" title="Ubah"><i class="fa-solid fa-pen"></i></button>
                  <button class="action-icon brick btn-hapus-santri" data-id="${s.id}" data-nama="${escapeHtml(s.nama)}" data-waliuid="${s.waliUid || ''}" title="Hapus"><i class="fa-solid fa-trash"></i></button>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>`;

      el.querySelectorAll('.btn-edit-santri').forEach((btn) => {
        btn.addEventListener('click', () => openSantriForm(list.find((s) => s.id === btn.dataset.id)));
      });
      el.querySelectorAll('.btn-hapus-santri').forEach((btn) => {
        btn.addEventListener('click', () => confirmHapusSantri(btn.dataset.id, btn.dataset.nama, btn.dataset.waliuid));
      });
    });
  });
}

function confirmHapusSantri(id, nama, waliUid) {
  openModal(`
    <div class="modal-head"><div><h3>Hapus santri?</h3></div><button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body"><p>Data ${escapeHtml(nama)} akan dihapus dan akun login walinya dinonaktifkan. Tindakan ini tidak dapat dibatalkan.</p></div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="document.getElementById('modal-backdrop').classList.remove('open')">Batal</button>
      <button class="btn btn-danger" id="btn-confirm-hapus-santri">Hapus</button>
    </div>
  `);
  document.getElementById('btn-confirm-hapus-santri').addEventListener('click', async () => {
    await deleteSantri(id);
    if (waliUid) {
      try { await deactivateAccount(waliUid); } catch (err) { console.warn('Gagal menonaktifkan akun wali:', err); }
    }
    closeModal();
    showToast('Data santri dihapus');
  });
}

function openSantriForm(santri) {
  openModal(`
    <div class="modal-head"><div><h3>${santri ? 'Ubah data santri' : 'Tambah santri baru'}</h3></div><button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="form-row"><label>Nama santri</label><input id="f-nama" value="${escapeHtml(santri?.nama || '')}" placeholder="Nama lengkap santri"></div>
      <div class="form-row"><label>Jilid / kelas</label><select id="f-jilid"></select></div>
      <div class="form-row"><label>Nama wali</label><input id="f-wali-nama" value="${escapeHtml(santri?.waliNama || '')}" placeholder="Nama wali santri"></div>
      <div class="form-row"><label>No. HP wali</label><input id="f-wali-hp" value="${escapeHtml(santri?.waliHp || '')}" placeholder="08xx-xxxx-xxxx"></div>
      ${!santri ? `
      <div class="two-col">
        <div class="form-row"><label>Username akun wali</label><input id="f-wali-username" placeholder="wali.namapanggilan"></div>
        <div class="form-row"><label>Kata sandi awal</label><input id="f-wali-password" type="text" placeholder="min. 6 karakter"></div>
      </div>
      <p style="font-size:11px;color:var(--ink-faint);">Akun login langsung dibuat otomatis. Sampaikan username + kata sandi ini ke wali santri untuk aktivasi pertama di aplikasi.</p>
      ` : `
      <div class="form-row"><button class="btn btn-ghost btn-sm" id="btn-reset-password" type="button"><i class="fa-solid fa-key"></i> Atur ulang kata sandi akun wali</button></div>
      `}
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="document.getElementById('modal-backdrop').classList.remove('open')">Batal</button>
      <button class="btn btn-primary" id="btn-simpan-santri">Simpan</button>
    </div>
  `);

  watchJilid((list) => {
    const sel = document.getElementById('f-jilid');
    if (!sel) return;
    sel.innerHTML = list.map((j) => `<option value="${j.id}" ${santri?.jilidId === j.id ? 'selected' : ''}>${escapeHtml(j.nama)}</option>`).join('');
  });

  document.getElementById('btn-reset-password')?.addEventListener('click', () => openResetPasswordModal(santri.waliUid, santri.waliNama));

  document.getElementById('btn-simpan-santri').addEventListener('click', async () => {
    const nama = document.getElementById('f-nama').value.trim();
    const jilidId = document.getElementById('f-jilid').value;
    const waliNama = document.getElementById('f-wali-nama').value.trim();
    const waliHp = document.getElementById('f-wali-hp').value.trim();
    if (!nama || !waliNama) { showToast('Nama santri dan wali wajib diisi'); return; }

    const btn = document.getElementById('btn-simpan-santri');

    if (santri) {
      await updateSantri(santri.id, { nama, jilidId, waliNama, waliHp });
      showToast('Data santri diperbarui');
      closeModal();
      return;
    }

    const username = document.getElementById('f-wali-username').value.trim();
    const password = document.getElementById('f-wali-password').value;
    if (!username || !password) { showToast('Username dan kata sandi akun wali wajib diisi'); return; }

    btn.disabled = true;
    btn.textContent = 'Menyimpan...';
    try {
      const santriId = await addSantri({ nama, jilidId, waliNama, waliHp, waliUid: '' });
      await provisionAccount({ role: 'wali', username, password, displayName: waliNama, refId: santriId });
      showToast(`Santri & akun wali "${username}" berhasil dibuat`);
      closeModal();
    } catch (err) {
      showToast(mapFunctionsError(err));
      btn.disabled = false;
      btn.textContent = 'Simpan';
    }
  });
}

function openResetPasswordModal(uid, personName) {
  if (!uid) { showToast('Akun belum memiliki login (data lama). Tambahkan lewat form baru.'); return; }
  openModal(`
    <div class="modal-head"><div><h3>Atur ulang kata sandi</h3><div class="sub">${escapeHtml(personName || '')}</div></div><button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="form-row"><label>Kata sandi baru</label><input id="f-new-password" type="text" placeholder="min. 6 karakter"></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="document.getElementById('modal-backdrop').classList.remove('open')">Batal</button>
      <button class="btn btn-primary" id="btn-confirm-reset">Simpan kata sandi baru</button>
    </div>
  `);
  document.getElementById('btn-confirm-reset').addEventListener('click', async () => {
    const pw = document.getElementById('f-new-password').value;
    if (!pw || pw.length < 6) { showToast('Kata sandi minimal 6 karakter'); return; }
    try {
      await resetAccountPassword(uid, pw);
      showToast('Kata sandi berhasil diatur ulang. Sampaikan kata sandi baru ke yang bersangkutan.');
      closeModal();
    } catch (err) {
      showToast(mapFunctionsError(err));
    }
  });
}

// ============================================================
// Data guru
// ============================================================
function renderGuruTab() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="panel">
      <div class="panel-head">
        <div><h3>Data guru (ustadzah)</h3><div class="sub" id="guru-count">Memuat...</div></div>
        <button class="btn btn-primary btn-sm" id="btn-tambah-guru"><i class="fa-solid fa-plus"></i> Tambah guru</button>
      </div>
      <div class="table-scroll" id="guru-list">${loadingNote()}</div>
    </div>
  `;
  document.getElementById('btn-tambah-guru').addEventListener('click', () => openGuruForm());

  watchJilid((jilidList) => {
    const jilidMap = Object.fromEntries(jilidList.map((j) => [j.id, j]));
    watchUstadzah((list) => {
      document.getElementById('guru-count').textContent = `${list.length} pengajar`;
      const el = document.getElementById('guru-list');
      if (list.length === 0) { el.innerHTML = emptyNote('Belum ada data guru.'); return; }
      el.innerHTML = `
        <table>
          <thead><tr><th>No.</th><th>Nama</th><th>Kelas diampu</th><th>No. HP</th><th>Aksi</th></tr></thead>
          <tbody>
            ${list.map((u, i) => `
              <tr>
                <td>${i + 1}</td>
                <td style="font-weight:600;">${escapeHtml(u.nama)}</td>
                <td>${escapeHtml(jilidMap[u.jilidId]?.nama || '—')}</td>
                <td>${escapeHtml(u.hp || '-')}</td>
                <td><button class="action-icon btn-edit-guru" data-id="${u.id}" title="Ubah"><i class="fa-solid fa-pen"></i></button></td>
              </tr>`).join('')}
          </tbody>
        </table>`;
      el.querySelectorAll('.btn-edit-guru').forEach((btn) => {
        btn.addEventListener('click', () => openGuruForm(list.find((u) => u.id === btn.dataset.id)));
      });
    });
  });
}

function openGuruForm(guru) {
  openModal(`
    <div class="modal-head"><div><h3>${guru ? 'Ubah data guru' : 'Tambah guru baru'}</h3></div><button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="form-row"><label>Nama ustadzah</label><input id="f-g-nama" value="${escapeHtml(guru?.nama || '')}" placeholder="Nama lengkap"></div>
      <div class="form-row"><label>No. HP</label><input id="f-g-hp" value="${escapeHtml(guru?.hp || '')}" placeholder="08xx-xxxx-xxxx"></div>
      ${!guru ? `
      <div class="two-col">
        <div class="form-row"><label>Username akun</label><input id="f-g-username" placeholder="ustadzah.namapanggilan"></div>
        <div class="form-row"><label>Kata sandi awal</label><input id="f-g-password" type="text" placeholder="min. 6 karakter"></div>
      </div>
      <p style="font-size:11px;color:var(--ink-faint);">Akun login langsung dibuat otomatis. Sampaikan username + kata sandi ini ke ustadzah untuk aktivasi pertama.</p>
      ` : `
      <div class="form-row"><button class="btn btn-ghost btn-sm" id="btn-reset-password-guru" type="button"><i class="fa-solid fa-key"></i> Atur ulang kata sandi</button></div>
      `}
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="document.getElementById('modal-backdrop').classList.remove('open')">Batal</button>
      <button class="btn btn-primary" id="btn-simpan-guru">Simpan</button>
    </div>
  `);

  document.getElementById('btn-reset-password-guru')?.addEventListener('click', () => openResetPasswordModal(guru.uid, guru.nama));

  document.getElementById('btn-simpan-guru').addEventListener('click', async () => {
    const nama = document.getElementById('f-g-nama').value.trim();
    const hp = document.getElementById('f-g-hp').value.trim();
    if (!nama) { showToast('Nama wajib diisi'); return; }

    const btn = document.getElementById('btn-simpan-guru');

    if (guru) {
      await updateUstadzah(guru.id, { nama, hp });
      showToast('Data guru diperbarui');
      closeModal();
      return;
    }

    const username = document.getElementById('f-g-username').value.trim();
    const password = document.getElementById('f-g-password').value;
    if (!username || !password) { showToast('Username dan kata sandi akun wajib diisi'); return; }

    btn.disabled = true;
    btn.textContent = 'Menyimpan...';
    try {
      const ustadzahId = await addUstadzah({ nama, hp, uid: '', jilidId: null });
      await provisionAccount({ role: 'ustadzah', username, password, displayName: nama, refId: ustadzahId });
      showToast(`Guru & akun "${username}" berhasil dibuat`);
      closeModal();
    } catch (err) {
      showToast(mapFunctionsError(err));
      btn.disabled = false;
      btn.textContent = 'Simpan';
    }
  });
}

// ============================================================
// Jilid / kelas
// ============================================================
function renderJilidTab() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="panel">
      <div class="panel-head">
        <div><h3>Jilid / kelas</h3><div class="sub">Pengampu &amp; buku ditetapkan di sini</div></div>
        <button class="btn btn-primary btn-sm" id="btn-tambah-jilid"><i class="fa-solid fa-plus"></i> Tambah jilid</button>
      </div>
      <div class="table-scroll" id="jilid-list">${loadingNote()}</div>
    </div>
  `;
  document.getElementById('btn-tambah-jilid').addEventListener('click', () => openJilidForm());

  watchUstadzah((ustadzahList) => {
    const ustadzahMap = Object.fromEntries(ustadzahList.map((u) => [u.id, u]));
    watchJilid((list) => {
      const el = document.getElementById('jilid-list');
      if (list.length === 0) { el.innerHTML = emptyNote('Belum ada jilid/kelas.'); return; }
      el.innerHTML = `
        <table>
          <thead><tr><th>Nama jilid / kelas</th><th>Ustadzah pengampu</th><th>Buku bacaan</th><th>Buku hafalan</th><th>Aksi</th></tr></thead>
          <tbody>
            ${list.map((j) => `
              <tr>
                <td style="font-weight:600;">${escapeHtml(j.nama)}</td>
                <td>${escapeHtml(ustadzahMap[j.ustadzahId]?.nama || '—')}</td>
                <td>${escapeHtml(j.bukuBacaanNama || '-')}</td>
                <td>${escapeHtml(j.bukuHafalanNama || '-')}</td>
                <td><button class="action-icon btn-edit-jilid" data-id="${j.id}" title="Ubah"><i class="fa-solid fa-pen"></i></button></td>
              </tr>`).join('')}
          </tbody>
        </table>`;
      el.querySelectorAll('.btn-edit-jilid').forEach((btn) => {
        btn.addEventListener('click', () => openJilidForm(list.find((j) => j.id === btn.dataset.id)));
      });
    });
  });
}

function openJilidForm(jilid) {
  state.ui.tempJilidFiles = { bacaan: null, hafalan: null };

  openModal(`
    <div class="modal-head"><div><h3>${jilid ? 'Ubah jilid / kelas' : 'Tambah jilid / kelas'}</h3></div><button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="form-row"><label>Nama jilid / kelas</label><input id="f-j-nama" value="${escapeHtml(jilid?.nama || '')}" placeholder="Contoh: Jilid 3"></div>
      <div class="form-row"><label>Ustadzah pengampu</label><select id="f-j-ustadzah"><option value="">— Belum ditentukan —</option></select></div>
      <div class="form-row">
        <label>Buku dibaca (unggah PDF)</label>
        <div class="upload-row">
          <input type="file" class="file-input" accept="application/pdf" id="f-j-bacaan-file">
          <div class="upload-current" id="f-j-bacaan-current"><i class="fa-solid fa-file-pdf"></i> ${escapeHtml(jilid?.bukuBacaanNama || 'Belum ada file')}</div>
        </div>
      </div>
      <div class="form-row">
        <label>Buku dihafal (unggah PDF)</label>
        <div class="upload-row">
          <input type="file" class="file-input" accept="application/pdf" id="f-j-hafalan-file">
          <div class="upload-current" id="f-j-hafalan-current"><i class="fa-solid fa-file-pdf"></i> ${escapeHtml(jilid?.bukuHafalanNama || 'Belum ada file')}</div>
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="document.getElementById('modal-backdrop').classList.remove('open')">Batal</button>
      <button class="btn btn-primary" id="btn-simpan-jilid">Simpan</button>
    </div>
  `);

  watchUstadzah((list) => {
    const sel = document.getElementById('f-j-ustadzah');
    if (!sel) return;
    sel.innerHTML = '<option value="">— Belum ditentukan —</option>' +
      list.map((u) => `<option value="${u.id}" ${jilid?.ustadzahId === u.id ? 'selected' : ''}>${escapeHtml(u.nama)}</option>`).join('');
  });

  document.getElementById('f-j-bacaan-file').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    state.ui.tempJilidFiles.bacaan = file;
    document.getElementById('f-j-bacaan-current').innerHTML = `<i class="fa-solid fa-circle-check" style="color:var(--pine);"></i> ${escapeHtml(file.name)} (siap diunggah)`;
  });
  document.getElementById('f-j-hafalan-file').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    state.ui.tempJilidFiles.hafalan = file;
    document.getElementById('f-j-hafalan-current').innerHTML = `<i class="fa-solid fa-circle-check" style="color:var(--pine);"></i> ${escapeHtml(file.name)} (siap diunggah)`;
  });

  document.getElementById('btn-simpan-jilid').addEventListener('click', async () => {
    const nama = document.getElementById('f-j-nama').value.trim();
    const ustadzahId = document.getElementById('f-j-ustadzah').value || null;
    if (!nama) { showToast('Nama jilid wajib diisi'); return; }

    const btn = document.getElementById('btn-simpan-jilid');
    btn.disabled = true;
    btn.textContent = 'Menyimpan...';

    try {
      const jilidId = await upsertJilid(jilid?.id, { nama, ustadzahId });

      const data = {};
      if (state.ui.tempJilidFiles.bacaan) {
        data.bukuBacaanUrl = await uploadBookPdf(jilidId, false, state.ui.tempJilidFiles.bacaan);
        data.bukuBacaanNama = state.ui.tempJilidFiles.bacaan.name;
      }
      if (state.ui.tempJilidFiles.hafalan) {
        data.bukuHafalanUrl = await uploadBookPdf(jilidId, true, state.ui.tempJilidFiles.hafalan);
        data.bukuHafalanNama = state.ui.tempJilidFiles.hafalan.name;
      }
      if (Object.keys(data).length > 0) await upsertJilid(jilidId, data);

      if (ustadzahId) await updateUstadzah(ustadzahId, { jilidId });

      showToast('Jilid tersimpan');
      closeModal();
    } catch (err) {
      showToast('Gagal menyimpan: ' + err.message);
      btn.disabled = false;
      btn.textContent = 'Simpan';
    }
  });
}

// ============================================================
// Pengaturan
// ============================================================
function renderPengaturanTab() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="panel" style="margin-bottom:16px;">
      <div class="panel-head"><div><h3>Identitas &amp; pembayaran lembaga</h3><div class="sub">Logo tampil di login &amp; header, QRIS tampil saat wali membayar</div></div></div>
      <div class="grid grid-2">
        <div>
          <span class="setting-label">Logo TPQ</span>
          <div class="upload-preview-row">
            <div class="logo-preview" id="logo-preview">TW</div>
            <div>
              <input type="file" class="file-input" accept="image/*" id="f-logo-file">
              <div style="font-size:11.5px;color:var(--ink-faint);margin-top:6px;">Format PNG/JPG, disarankan bentuk persegi.</div>
            </div>
          </div>
        </div>
        <div>
          <span class="setting-label">QRIS pembayaran lembaga</span>
          <div class="upload-preview-row">
            <div class="qris-preview" id="qris-preview"><i class="fa-solid fa-qrcode"></i></div>
            <div>
              <input type="file" class="file-input" accept="image/*" id="f-qris-file">
              <div style="font-size:11.5px;color:var(--ink-faint);margin-top:6px;">Unggah gambar QRIS statis resmi TPQ.</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="grid grid-2">
      <div class="panel">
        <div class="panel-head"><h3>Tagihan SPP</h3></div>
        <div class="form-row"><label>Nominal SPP per bulan</label><input type="number" id="s-spp-nominal"></div>
        <div class="form-row"><label>Tanggal jatuh tempo (tiap bulan)</label><input type="number" id="s-spp-jatuh" min="1" max="28"></div>
        <button class="btn btn-primary btn-sm" id="btn-simpan-spp">Simpan pengaturan SPP</button>
      </div>
      <div class="panel">
        <div class="panel-head"><h3>Tabungan</h3></div>
        <div class="form-row"><label>Minimal setoran per bulan</label><input type="number" id="s-tab-nominal"></div>
        <div class="form-row"><label>Keterangan</label><textarea id="s-tab-ket"></textarea></div>
        <button class="btn btn-primary btn-sm" id="btn-simpan-tabungan">Simpan pengaturan tabungan</button>
      </div>
    </div>

    <div class="panel" style="margin-top:16px;">
      <div class="panel-head"><div><h3>Iuran kegiatan</h3></div><button class="btn btn-gold btn-sm" id="btn-tambah-iuran"><i class="fa-solid fa-plus"></i> Tambah iuran</button></div>
      <div class="table-scroll" id="iuran-list">${loadingNote()}</div>
    </div>

    <div class="panel" style="margin-top:16px;">
      <div class="panel-head"><div><h3>Buku PDF per jilid</h3><div class="sub">Ditampilkan otomatis di portal ustadzah &amp; wali</div></div></div>
      <div class="table-scroll" id="buku-per-jilid">${loadingNote()}</div>
    </div>

    <div class="panel" style="margin-top:16px;">
      <div class="panel-head"><div><h3>Info pengumuman</h3></div><button class="btn btn-gold btn-sm" id="btn-tambah-pengumuman"><i class="fa-solid fa-plus"></i> Buat pengumuman</button></div>
      <div id="pengumuman-list">${loadingNote()}</div>
    </div>
  `;

  wireBrandingSection();
  wireSppTabunganSection();
  wireIuranSection();
  wireBukuPerJilidSection();
  wirePengumumanSection();
}

function wireBrandingSection() {
  watchSettings((settings) => {
    const logoPreview = document.getElementById('logo-preview');
    const qrisPreview = document.getElementById('qris-preview');
    if (logoPreview) logoPreview.innerHTML = settings.logoUrl ? `<img src="${settings.logoUrl}" alt="Pratinjau logo">` : 'TW';
    if (qrisPreview) qrisPreview.innerHTML = settings.qrisUrl ? `<img src="${settings.qrisUrl}" alt="Pratinjau QRIS">` : '<i class="fa-solid fa-qrcode"></i>';
    applyBranding(settings.logoUrl);
  });

  document.getElementById('f-logo-file').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    showToast('Mengunggah logo...');
    const url = await uploadLogo(file);
    await updateSettings({ logoUrl: url });
    showToast('Logo lembaga diperbarui');
  });
  document.getElementById('f-qris-file').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    showToast('Mengunggah QRIS...');
    const url = await uploadQris(file);
    await updateSettings({ qrisUrl: url });
    showToast('QRIS lembaga diperbarui');
  });
}

function wireSppTabunganSection() {
  let filled = false;
  watchSettings((settings) => {
    if (!filled) {
      document.getElementById('s-spp-nominal').value = settings.sppNominal ?? 150000;
      document.getElementById('s-spp-jatuh').value = settings.sppJatuhTempo ?? 10;
      document.getElementById('s-tab-nominal').value = settings.tabunganMinSetor ?? 20000;
      document.getElementById('s-tab-ket').value = settings.tabunganKeterangan ?? '';
      filled = true;
    }
  });

  document.getElementById('btn-simpan-spp').addEventListener('click', async () => {
    await updateSettings({
      sppNominal: parseInt(document.getElementById('s-spp-nominal').value, 10) || 0,
      sppJatuhTempo: parseInt(document.getElementById('s-spp-jatuh').value, 10) || 10,
    });
    showToast('Pengaturan SPP disimpan');
  });
  document.getElementById('btn-simpan-tabungan').addEventListener('click', async () => {
    await updateSettings({
      tabunganMinSetor: parseInt(document.getElementById('s-tab-nominal').value, 10) || 0,
      tabunganKeterangan: document.getElementById('s-tab-ket').value,
    });
    showToast('Pengaturan tabungan disimpan');
  });
}

function wireIuranSection() {
  watchIuranItems((list) => {
    const el = document.getElementById('iuran-list');
    if (!el) return;
    if (list.length === 0) { el.innerHTML = emptyNote('Belum ada iuran kegiatan.'); return; }
    el.innerHTML = `
      <table>
        <thead><tr><th>Nama iuran</th><th>Nominal</th><th>Batas waktu</th><th>Aksi</th></tr></thead>
        <tbody>
          ${list.map((it) => `
            <tr><td>${escapeHtml(it.nama)}</td><td>${rupiah(it.nominal)}</td><td>${tanggalIndo(it.deadline)}</td>
            <td><button class="action-icon brick btn-hapus-iuran" data-id="${it.id}" title="Hapus"><i class="fa-solid fa-trash"></i></button></td></tr>
          `).join('')}
        </tbody>
      </table>`;
    el.querySelectorAll('.btn-hapus-iuran').forEach((btn) => {
      btn.addEventListener('click', async () => { await hapusIuranSetting(btn.dataset.id); showToast('Iuran dihapus dari pengaturan'); });
    });
  });

  document.getElementById('btn-tambah-iuran').addEventListener('click', () => {
    openModal(`
      <div class="modal-head"><div><h3>Tambah iuran kegiatan</h3></div><button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="form-row"><label>Nama kegiatan</label><input id="f-iuran-nama" placeholder="Contoh: Iuran Pondok Ramadhan"></div>
        <div class="form-row"><label>Nominal</label><input type="number" id="f-iuran-nominal" placeholder="0"></div>
        <div class="form-row"><label>Batas waktu</label><input type="date" id="f-iuran-deadline"></div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-ghost" onclick="document.getElementById('modal-backdrop').classList.remove('open')">Batal</button>
        <button class="btn btn-primary" id="btn-simpan-iuran">Simpan &amp; kirim tagihan</button>
      </div>
    `);
    document.getElementById('btn-simpan-iuran').addEventListener('click', async () => {
      const nama = document.getElementById('f-iuran-nama').value.trim();
      const nominal = parseInt(document.getElementById('f-iuran-nominal').value, 10) || 0;
      const deadlineStr = document.getElementById('f-iuran-deadline').value;
      const deadline = deadlineStr ? new Date(deadlineStr) : new Date();
      if (!nama) { showToast('Nama iuran wajib diisi'); return; }

      await tambahIuranSetting(nama, nominal, deadline);
      const allSantri = await new Promise((resolve) => { const u = watchAllSantri((list) => { u(); resolve(list); }); });
      await broadcastIuranKeSemuaSantri(allSantri.map((s) => s.id), nama, nominal);

      showToast('Iuran baru dibuat dan tagihan dikirim ke seluruh santri');
      closeModal();
    });
  });
}

function wireBukuPerJilidSection() {
  watchUstadzah(() => {}); // no-op warm-up, data dipakai lewat watchJilid saja di sini
  watchJilid((list) => {
    const el = document.getElementById('buku-per-jilid');
    if (!el) return;
    if (list.length === 0) { el.innerHTML = emptyNote('Belum ada jilid/kelas.'); return; }
    el.innerHTML = `
      <table>
        <thead><tr><th>Jilid / kelas</th><th>Buku bacaan</th><th>Buku hafalan</th><th>Aksi</th></tr></thead>
        <tbody>
          ${list.map((j) => `<tr><td style="font-weight:600;">${escapeHtml(j.nama)}</td><td>${escapeHtml(j.bukuBacaanNama || '-')}</td><td>${escapeHtml(j.bukuHafalanNama || '-')}</td>
            <td><button class="btn btn-ghost btn-sm btn-atur-buku" data-id="${j.id}"><i class="fa-solid fa-file-pdf"></i> Atur buku</button></td></tr>`).join('')}
        </tbody>
      </table>`;
    el.querySelectorAll('.btn-atur-buku').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const j = await getJilid(btn.dataset.id);
        openJilidForm(j);
      });
    });
  });
}

function wirePengumumanSection() {
  watchPengumuman((list) => {
    const el = document.getElementById('pengumuman-list');
    if (!el) return;
    if (list.length === 0) { el.innerHTML = emptyNote('Belum ada pengumuman.'); return; }
    el.innerHTML = list.map((p) => `
      <div class="announce-item" style="display:flex;justify-content:space-between;gap:10px;">
        <div>
          <div class="a-title">${escapeHtml(p.judul)}</div>
          <div class="a-date">${tanggalIndo(p.tanggal)}</div>
          <div class="a-body">${escapeHtml(p.isi)}</div>
        </div>
        <button class="action-icon brick btn-hapus-pengumuman" data-id="${p.id}" title="Hapus" style="flex-shrink:0;height:32px;"><i class="fa-solid fa-trash"></i></button>
      </div>
    `).join('');
    el.querySelectorAll('.btn-hapus-pengumuman').forEach((btn) => {
      btn.addEventListener('click', async () => { await hapusPengumuman(btn.dataset.id); showToast('Pengumuman dihapus'); });
    });
  });

  document.getElementById('btn-tambah-pengumuman').addEventListener('click', () => {
    openModal(`
      <div class="modal-head"><div><h3>Buat pengumuman</h3></div><button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="form-row"><label>Judul</label><input id="f-p-judul" placeholder="Judul pengumuman"></div>
        <div class="form-row"><label>Isi pengumuman</label><textarea id="f-p-isi" placeholder="Tuliskan isi pengumuman untuk wali santri..."></textarea></div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-ghost" onclick="document.getElementById('modal-backdrop').classList.remove('open')">Batal</button>
        <button class="btn btn-primary" id="btn-simpan-pengumuman">Terbitkan</button>
      </div>
    `);
    document.getElementById('btn-simpan-pengumuman').addEventListener('click', async () => {
      const judul = document.getElementById('f-p-judul').value.trim();
      const isi = document.getElementById('f-p-isi').value.trim();
      if (!judul || !isi) { showToast('Judul dan isi wajib diisi'); return; }
      await tambahPengumuman(judul, isi);
      showToast('Pengumuman diterbitkan ke seluruh wali santri');
      closeModal();
    });
  });
}
