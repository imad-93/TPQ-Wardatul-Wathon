export function rupiah(n) {
  return 'Rp' + Number(n || 0).toLocaleString('id-ID');
}

export function tanggalIndo(dateLike) {
  if (!dateLike) return '-';
  const date = dateLike.toDate ? dateLike.toDate() : new Date(dateLike);
  if (isNaN(date.getTime())) return '-';
  const bln = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  return `${date.getDate()} ${bln[date.getMonth()]} ${date.getFullYear()}`;
}

export function initials(name) {
  if (!name) return '?';
  return name
    .split(' ')
    .filter((w) => !/^(bpk\.?|ibu)$/i.test(w))
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();
}

export function durationLabel(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}
