import {
  getJilid, watchSantriByJilid, watchRiwayat, tambahRiwayat,
  watchKeuangan, tandaiLunas, tambahTagihan, watchSettings,
} from './db.js';
import { uploadVoiceNote } from './storage.js';
import { rupiah, tanggalIndo, initials, durationLabel, escapeHtml } from './formatters.js';
import { openModal, closeModal, showToast, emptyNote, loadingNote } from './ui-shared.js';
import { state } from './state.js';
import { collection, query, where, limit, getDocs } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import { db } from './firebase-config.js';

export async function renderUstadzahShell(session) {
  const content = document.getElementById('content');
  content.innerHTML = loadingNote('Memuat data kelas...');

  // Cari dokumen ustadzah yang uid-nya cocok dengan sesi login.
  const q = query(collection(db, 'ustadzah'), where('uid', '==', session.uid), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) {
    content.innerHTML = `<div class="panel">${emptyNote('Data ustadzah tidak ditemukan untuk akun ini. Hubungi admin TPQ.')}</div>`;
    return;
  }
  const ustadzah = { id: snap.docs[0].id, ...snap.docs[0].data() };
  if (!ustadzah.jilidId) {
    content.innerHTML = `<div class="panel">${emptyNote('Anda belum ditugaskan ke jilid/kelas manapun.')}</div>`;
    return;
  }

  const jilid = await getJilid(ustadzah.jilidId);

  content.innerHTML = `
    <div class="hero">
      <div class="hero-eyebrow">Assalamu'alaikum, ${escapeHtml(ustadzah.nama)}</div>
      <h2>${escapeHtml(jilid?.nama || 'Kelas')}</h2>
      <p>Kelola bacaan, hafalan, dan keuangan santri langsung dari daftar di bawah.</p>
    </div>

    <div class="grid grid-3" style="margin-bottom:16px;">
      <div class="stat-card"><div class="stat-label">Jumlah santri</div><div class="stat-value" id="stat-jumlah-santri">-</div><div class="stat-note">di ${escapeHtml(jilid?.nama || '')}</div></div>
      <div class="stat-card gold"><div class="stat-label">Buku bacaan</div><div class="stat-value" style="font-size:16px;">${escapeHtml(jilid?.bukuBacaanNama || '-')}</div><div class="stat-note">diatur admin</div></div>
      <div class="stat-card brick"><div class="stat-label">Buku hafalan</div><div class="stat-value" style="font-size:16px;">${escapeHtml(jilid?.bukuHafalanNama || '-')}</div><div class="stat-note">diatur admin</div></div>
    </div>

    <div class="panel">
      <div class="panel-head"><div><h3>Daftar santri</h3><div class="sub">${escapeHtml(jilid?.nama || '')}</div></div></div>
      <div class="table-scroll" id="santri-table">${loadingNote()}</div>
    </div>
  `;

  watchSantriByJilid(ustadzah.jilidId, (list) => {
    document.getElementById('stat-jumlah-santri').textContent = list.length;
    const el = document.getElementById('santri-table');
    if (list.length === 0) {
      el.innerHTML = emptyNote('Belum ada santri di kelas ini.');
      return;
    }
    el.innerHTML = `
      <table>
        <thead><tr><th>No.</th><th>Nama santri</th><th>Aksi</th></tr></thead>
        <tbody>
          ${list.map((s, i) => `
            <tr>
              <td>${i + 1}</td>
              <td>
                <div class="person-row">
                  <div class="avatar small">${initials(s.nama)}</div>
                  <span style="font-weight:600;">${escapeHtml(s.nama)}</span>
                </div>
              </td>
              <td>
                <button class="action-icon btn-buku" data-id="${s.id}" data-nama="${escapeHtml(s.nama)}" data-hafalan="0" title="Buku dibaca"><i class="fa-solid fa-book-open"></i></button>
                <button class="action-icon gold btn-buku" data-id="${s.id}" data-nama="${escapeHtml(s.nama)}" data-hafalan="1" title="Buku dihafal"><i class="fa-solid fa-bookmark"></i></button>
                <button class="action-icon brick btn-keuangan" data-id="${s.id}" data-nama="${escapeHtml(s.nama)}" title="Keuangan"><i class="fa-solid fa-wallet"></i></button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>`;

    el.querySelectorAll('.btn-buku').forEach((btn) => {
      btn.addEventListener('click', () => openBookModal(btn.dataset.id, btn.dataset.nama, jilid, btn.dataset.hafalan === '1'));
    });
    el.querySelectorAll('.btn-keuangan').forEach((btn) => {
      btn.addEventListener('click', () => openFinanceModal(btn.dataset.id, btn.dataset.nama));
    });
  });
}

// ============================================================
// Modal: Buku dibaca / dihafal
// ============================================================
function openBookModal(santriId, santriNama, jilid, hafalan) {
  const buku = hafalan ? (jilid?.bukuHafalanNama || '-') : (jilid?.bukuBacaanNama || '-');
  resetRecordingState();

  openModal(`
    <div class="modal-head">
      <div><h3>${hafalan ? 'Buku dihafal' : 'Buku dibaca'} — ${escapeHtml(santriNama)}</h3><div class="sub">${escapeHtml(buku)}</div></div>
      <button class="modal-close" id="btn-close-book"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" id="book-modal-body">${loadingNote()}</div>
  `, true);

  document.getElementById('btn-close-book').addEventListener('click', () => { stopRecordingIfActive(); closeModal(); });

  watchRiwayat(santriId, hafalan, (list) => {
    const bodyEl = document.getElementById('book-modal-body');
    if (!bodyEl) return; // modal sudah ditutup
    const last = list[0] || { halaman: 1, status: 'naik' };
    bodyEl.innerHTML = renderBookModalBody(santriId, santriNama, hafalan, buku, last, list);
    wireBookModalEvents(santriId, hafalan, last);
  });
}

function renderBookModalBody(santriId, santriNama, hafalan, buku, last, list) {
  return `
    <div class="page-viewer">
      <div class="pv-book">${escapeHtml(buku)}</div>
      <div class="pv-page">Hal. ${last.halaman}</div>
      <div class="pv-note">Terakhir dibuka — pertemuan berikutnya otomatis membuka halaman ini</div>
    </div>

    <div class="two-col" style="margin-bottom:14px;">
      <div class="form-row" style="margin-bottom:0;">
        <label>Tandai halaman ini</label>
        <input type="number" id="halaman-input" value="${last.halaman}" min="1">
      </div>
      <div class="form-row" style="margin-bottom:0;display:flex;flex-direction:column;">
        <label>&nbsp;</label>
        <button class="btn btn-primary" style="width:100%;" id="btn-simpan-halaman"><i class="fa-solid fa-bookmark"></i> Simpan halaman</button>
      </div>
    </div>

    <div class="two-col" style="margin-bottom:16px;">
      <button class="btn btn-ghost" id="btn-tandai-naik"><i class="fa-solid fa-arrow-up"></i> Tandai naik</button>
      <button class="btn btn-ghost" id="btn-tandai-mengulang"><i class="fa-solid fa-rotate-left"></i> Tandai mengulang</button>
    </div>

    <div class="form-row">
      <label>Pesan untuk wali santri</label>
      <textarea id="pesan-teks" placeholder="Tuliskan catatan singkat untuk wali santri..."></textarea>
    </div>
    <div class="mic-box">
      <button class="mic-circle" id="mic-btn"><i class="fa-solid fa-microphone"></i></button>
      <div style="flex:1;">
        <div id="mic-status" style="font-size:12.5px;color:var(--ink-soft);">Tekan untuk merekam pesan suara</div>
        <audio id="mic-preview" controls style="display:none;width:100%;height:32px;margin-top:6px;"></audio>
      </div>
      <div class="mic-time" id="mic-time">0:00</div>
    </div>
    <button class="btn btn-gold" style="width:100%;margin-bottom:18px;" id="btn-kirim-pesan"><i class="fa-solid fa-paper-plane"></i> Kirim pesan ke wali</button>

    <div class="panel-head" style="margin-bottom:8px;"><h3 style="font-size:14px;">Riwayat</h3></div>
    <div class="table-scroll">
      <table>
        <thead><tr><th>No.</th><th>Halaman</th><th>Status</th><th>Pesan</th><th>Tanggal</th></tr></thead>
        <tbody>
          ${list.length === 0 ? `<tr><td colspan="5">${emptyNote('Belum ada riwayat.')}</td></tr>` :
          list.map((r, i) => `
            <tr>
              <td>${i + 1}</td>
              <td>Hal. ${r.halaman}</td>
              <td>${r.status === 'naik' ? '<span class="badge badge-green">Naik</span>' : '<span class="badge badge-brick">Mengulang</span>'}</td>
              <td>${r.pesanTipe === 'suara'
                ? `<div class="voice-msg"><button class="vm-play" onclick="window.open('${r.audioUrl || '#'}','_blank')"><i class="fa-solid fa-play"></i></button>${escapeHtml(r.pesan)}</div>`
                : escapeHtml(r.pesan || '-')}</td>
              <td style="white-space:nowrap;font-size:12px;color:var(--ink-faint);">${tanggalIndo(r.tanggal)}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function wireBookModalEvents(santriId, hafalan, last) {
  document.getElementById('btn-simpan-halaman')?.addEventListener('click', async () => {
    const val = parseInt(document.getElementById('halaman-input').value, 10) || 1;
    await tambahRiwayat(santriId, hafalan, {
      halaman: val, status: 'naik', pesan: 'Halaman ditandai oleh ustadzah.', pesanTipe: 'teks', audioUrl: null,
    });
    showToast('Halaman tersimpan — pertemuan berikutnya otomatis dibuka di halaman ini');
  });

  document.getElementById('btn-tandai-naik')?.addEventListener('click', async () => {
    await tambahRiwayat(santriId, hafalan, {
      halaman: last.halaman, status: 'naik', pesan: 'Alhamdulillah, bacaan sudah baik.', pesanTipe: 'teks', audioUrl: null,
    });
    showToast('Ditandai naik');
  });

  document.getElementById('btn-tandai-mengulang')?.addEventListener('click', async () => {
    await tambahRiwayat(santriId, hafalan, {
      halaman: last.halaman, status: 'mengulang', pesan: 'Perlu diulang, latihan sedikit lagi ya.', pesanTipe: 'teks', audioUrl: null,
    });
    showToast('Ditandai mengulang');
  });

  document.getElementById('mic-btn')?.addEventListener('click', toggleRecording);

  document.getElementById('btn-kirim-pesan')?.addEventListener('click', async () => {
    const pesanTeks = document.getElementById('pesan-teks').value.trim();
    const btn = document.getElementById('btn-kirim-pesan');

    if (state.ui.recordedBlob) {
      btn.disabled = true;
      btn.textContent = 'Mengunggah pesan suara...';
      try {
        const fileName = `pesan_${Date.now()}.webm`;
        const url = await uploadVoiceNote(santriId, state.ui.recordedBlob, fileName);
        await tambahRiwayat(santriId, hafalan, {
          halaman: last.halaman, status: last.status || 'naik',
          pesan: `Pesan suara (${durationLabel(state.ui.recordSeconds)})`, pesanTipe: 'suara', audioUrl: url,
        });
        showToast('Pesan suara terkirim ke wali santri');
        resetRecordingState();
      } catch (err) {
        showToast('Gagal mengunggah pesan suara: ' + err.message);
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Kirim pesan ke wali';
      }
      return;
    }

    if (!pesanTeks) {
      showToast('Tulis pesan atau rekam pesan suara terlebih dahulu');
      return;
    }
    await tambahRiwayat(santriId, hafalan, {
      halaman: last.halaman, status: last.status || 'naik', pesan: pesanTeks, pesanTipe: 'teks', audioUrl: null,
    });
    document.getElementById('pesan-teks').value = '';
    showToast('Pesan terkirim ke wali santri');
  });
}

// ---------- Rekam suara (Web MediaRecorder API) ----------
function resetRecordingState() {
  state.ui.recording = false;
  state.ui.recordSeconds = 0;
  state.ui.recordedChunks = [];
  state.ui.recordedBlob = null;
  clearInterval(state.ui.recordTimer);
  state.ui.recordTimer = null;
}

function stopRecordingIfActive() {
  if (state.ui.mediaRecorder && state.ui.mediaRecorder.state === 'recording') {
    state.ui.mediaRecorder.stop();
  }
  clearInterval(state.ui.recordTimer);
}

async function toggleRecording() {
  const micBtn = document.getElementById('mic-btn');
  const micStatus = document.getElementById('mic-status');
  const micTime = document.getElementById('mic-time');
  const micPreview = document.getElementById('mic-preview');

  if (state.ui.recording) {
    state.ui.mediaRecorder?.stop();
    return;
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    state.ui.mediaRecorder = recorder;
    state.ui.recordedChunks = [];
    state.ui.recordSeconds = 0;

    recorder.ondataavailable = (e) => { if (e.data.size > 0) state.ui.recordedChunks.push(e.data); };
    recorder.onstop = () => {
      const blob = new Blob(state.ui.recordedChunks, { type: 'audio/webm' });
      state.ui.recordedBlob = blob;
      state.ui.recording = false;
      clearInterval(state.ui.recordTimer);
      stream.getTracks().forEach((t) => t.stop());

      micBtn.classList.remove('recording');
      micBtn.innerHTML = '<i class="fa-solid fa-microphone"></i>';
      if (micStatus) micStatus.textContent = `Rekaman siap (${durationLabel(state.ui.recordSeconds)})`;
      if (micPreview) {
        micPreview.src = URL.createObjectURL(blob);
        micPreview.style.display = 'block';
      }
    };

    recorder.start();
    state.ui.recording = true;
    micBtn.classList.add('recording');
    micBtn.innerHTML = '<i class="fa-solid fa-stop"></i>';
    if (micStatus) micStatus.textContent = 'Merekam...';
    if (micPreview) micPreview.style.display = 'none';

    state.ui.recordTimer = setInterval(() => {
      state.ui.recordSeconds += 1;
      if (micTime) micTime.textContent = durationLabel(state.ui.recordSeconds);
    }, 1000);
  } catch (err) {
    showToast('Izin mikrofon ditolak atau tidak tersedia di perangkat ini.');
  }
}

// ============================================================
// Modal: Keuangan (SPP / Tabungan / Iuran)
// ============================================================
function openFinanceModal(santriId, santriNama) {
  state.ui.financeTab = 'spp';
  openModal(`
    <div class="modal-head">
      <div><h3>Keuangan — ${escapeHtml(santriNama)}</h3><div class="sub">SPP, tabungan &amp; iuran kegiatan</div></div>
      <button class="modal-close" onclick="document.getElementById('modal-backdrop').classList.remove('open')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" id="finance-modal-body">${loadingNote()}</div>
  `, true);

  renderFinanceTab(santriId);
}

function renderFinanceTab(santriId) {
  const tab = state.ui.financeTab;
  watchKeuangan(santriId, async (all) => {
    const bodyEl = document.getElementById('finance-modal-body');
    if (!bodyEl) return;
    const filtered = all.filter((k) => k.jenis === tab);
    const settings = await new Promise((resolve) => { const u = watchSettings((s) => { u(); resolve(s); }); });

    let extra = '';
    if (tab === 'spp') extra = `<p style="font-size:12px;color:var(--ink-faint);margin-bottom:12px;">Nominal SPP: ${rupiah(settings.sppNominal || 0)} · jatuh tempo tanggal ${settings.sppJatuhTempo || '-'} tiap bulan (diatur admin).</p>`;
    else if (tab === 'tabungan') extra = `<p style="font-size:12px;color:var(--ink-faint);margin-bottom:12px;">Minimal setoran ${rupiah(settings.tabunganMinSetor || 0)}/bulan. ${escapeHtml(settings.tabunganKeterangan || '')}</p>`;
    else extra = `<p style="font-size:12px;color:var(--ink-faint);margin-bottom:12px;">Daftar iuran kegiatan aktif diatur oleh admin.</p>`;

    bodyEl.innerHTML = `
      <div class="tabs">
        <button class="tab-btn ${tab === 'spp' ? 'active' : ''}" data-tab="spp">SPP</button>
        <button class="tab-btn ${tab === 'tabungan' ? 'active' : ''}" data-tab="tabungan">Tabungan</button>
        <button class="tab-btn ${tab === 'iuran' ? 'active' : ''}" data-tab="iuran">Iuran kegiatan</button>
      </div>
      ${extra}
      <div class="table-scroll">
        <table>
          <thead><tr><th>Label</th><th>Nominal</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
            ${filtered.length === 0 ? `<tr><td colspan="4">${emptyNote('Belum ada catatan.')}</td></tr>` :
            filtered.map((k) => `
              <tr>
                <td>${escapeHtml(k.label)}</td>
                <td>${rupiah(k.nominal)}</td>
                <td>${k.status === 'lunas' ? `<span class="badge badge-green">Lunas · ${tanggalIndo(k.tanggalBayar)}</span>` : `<span class="badge badge-brick">Belum lunas</span>`}</td>
                <td>${k.status === 'lunas'
                  ? `<span style="font-size:12px;color:var(--ink-faint);">via ${escapeHtml(k.metode || '-')}</span>`
                  : `<button class="btn btn-ghost btn-sm btn-tandai-lunas" data-id="${k.id}">Tandai lunas (tunai)</button>`}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
      ${tab === 'tabungan' ? `<button class="btn btn-gold" style="margin-top:14px;" id="btn-tambah-setoran"><i class="fa-solid fa-plus"></i> Catat setoran tabungan baru</button>` : ''}
    `;

    bodyEl.querySelectorAll('.tab-btn').forEach((btn) => {
      btn.addEventListener('click', () => { state.ui.financeTab = btn.dataset.tab; renderFinanceTab(santriId); });
    });
    bodyEl.querySelectorAll('.btn-tandai-lunas').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await tandaiLunas(santriId, btn.dataset.id, 'Tunai');
        showToast('Ditandai lunas (tunai)');
      });
    });
    bodyEl.querySelector('#btn-tambah-setoran')?.addEventListener('click', async () => {
      const bulanNama = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
      const now = new Date();
      await tambahTagihan(santriId, {
        jenis: 'tabungan',
        label: `Tabungan ${bulanNama[now.getMonth()]} ${now.getFullYear()}`,
        nominal: settings.tabunganMinSetor || 0,
        status: 'belum', metode: '-', tanggalBayar: null,
      });
      showToast('Tagihan tabungan baru ditambahkan');
    });
  });
}
